<img src="https://raw.githubusercontent.com/hilanmiao/LanMiaoDesktop/master/assets/logo.png">

# <span style="font-weight:400;">PocketBook</span> <span style="font-size:14px">0.0.1</span>

> <span style="line-height:1.8rem;font-weight:400;font-size:1.3rem">A simple electron application<span>

[Star Me](https://github.com/hilanmiao/LanMiaoDesktop)
[Get Started](#main)
